import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
// import { PersonalListComponent } from './personal/components/personal-list/personal-list.component';
// import { AgregarPersonaComponent } from './personal/components/agregar-persona/agregar-persona.component';
// import { EditPersonaComponent } from './personal/components/edit-persona/edit-persona.component';
  //--- Autenticacion
// import { RegistroComponent } from './auth/components/registro/registro.component';
// import { LoginComponent } from './auth/components/login/login.component';
import { AppComponent } from './app.component';

const routes: Routes = [
  // { path: '', component: AppComponent},
   { path: '', redirectTo: 'auth', pathMatch: 'full' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
