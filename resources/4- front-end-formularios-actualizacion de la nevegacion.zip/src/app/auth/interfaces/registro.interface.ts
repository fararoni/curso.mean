export interface Registro {
    nombre: string,
    email: string,
    password: string,
    password2: string
}