import { Component } from '@angular/core';

@Component({
  selector: 'app-auth',
  template: `
    <div class="container">
      <div class="text-center">
          <router-outlet></router-outlet>
      </div>
    </div>
  `,
  styles: [
  ]
})
export class AuthComponent {

}