import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonalComponent } from './personal.component'
import { PersonalListComponent } from './components/personal-list/personal-list.component';
import { AgregarPersonaComponent } from './components/agregar-persona/agregar-persona.component';
import { EditPersonaComponent } from './components/edit-persona/edit-persona.component';


const routes: Routes = [
  
  { path: 'personal', component: PersonalComponent ,
    children:[
      {path:'', component: PersonalListComponent},
      {path:'nuevo', component: AgregarPersonaComponent},
      {path:'editar/:id', component: EditPersonaComponent}
    ]
  }
  /*//--- { path: '', redirectTo: 'personas', pathMatch: 'full' },
  { path: '', redirectTo:'auth', pathMatch:'full'},
  { path: 'personas', component: PersonalListComponent },
  { path: 'personas/nuevo', component: AgregarPersonaComponent },
  { path: 'personas/editar/:id', component: EditPersonaComponent }, */
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PersonalRoutingModule { }
