import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

 import { PersonalRoutingModule } from './personal.routing';

import { PersonalComponent } from './personal.component';
import { PersonalListComponent } from './components/personal-list/personal-list.component';
import { PersonalFormComponent } from './components/personal-form/personal-form.component';
import { AgregarPersonaComponent } from './components/agregar-persona/agregar-persona.component';
import { EditPersonaComponent } from './components/edit-persona/edit-persona.component';

@NgModule({
  declarations: [
    PersonalComponent,
    PersonalListComponent,
    PersonalFormComponent,
    AgregarPersonaComponent,
    EditPersonaComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    PersonalRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports:[
    PersonalComponent,
    PersonalListComponent,
    PersonalFormComponent,
    AgregarPersonaComponent,
    EditPersonaComponent
  ]
})
export class PersonalModule { }
