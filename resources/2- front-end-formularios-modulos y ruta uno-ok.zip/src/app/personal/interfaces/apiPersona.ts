export interface apiPersona {
    result?: string;
    directorio?: any;
}
