import { Component } from '@angular/core';

@Component({
  selector: 'app-personal',
  template: `
    <p>
      personal works - personal!
      <router-outlet></router-outlet>
    </p>
  `,
  styles: [
  ]
})
export class PersonalComponent {

}