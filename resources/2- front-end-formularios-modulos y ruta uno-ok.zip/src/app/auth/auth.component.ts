import { Component } from '@angular/core';

@Component({
  selector: 'app-auth',
  template: `
    <p>
      auth works - Auth!
      <router-outlet></router-outlet>
      
    </p>
  `,
  styles: [
  ]
})
export class AuthComponent {

}