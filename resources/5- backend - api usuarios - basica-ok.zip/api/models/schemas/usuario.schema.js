const { Schema } = require('mongoose');

const UsuarioSchema = Schema({
    nombre:     { type: String,  required: true },
    email:      {  type: String, required: true },
    password:   { type: String,  required: true },
    password2:  { type: String},
    role: {
        type: String,
        require: true,
        default: 'USER_ROLE'
    }
})


module.exports = { UsuarioSchema }