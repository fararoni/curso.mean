const mongoose = require('mongoose')

const { UsuarioSchema } = require('./schemas/usuario.schema')
const UsuarioModel = mongoose.model('usuarios_collection', UsuarioSchema )

module.exports = { UsuarioModel }