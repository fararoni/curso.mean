const { Router } =  require('express');
const router = Router();

const userController = require('../controllers/usuario.controller')

router.get   ('/usuarios'     , userController.readAllUsuarios )
router.get   ('/usuario/:id'  , userController.readOneUsuario )
router.post  ('/usuario'      , userController.createUsuario )
router.put   ('/usuario/:id'  , userController.updateUsuario )

console.log  ('auth.router')
module.exports = router