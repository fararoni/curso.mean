const { UsuarioModel } = require('../models/usuario.model');

const readAllUsuarios = async (req, res) => {
    console.log('-> readAllUsuarios')
    try {
        const usuarios = await UsuarioModel.find({})
        res.status(200)
        res.json({ result: 'Ok', usuarios: usuarios })
    } catch (error) {
        console.log('Exception en readAllUsuarios: ' + error.message)
        res.status(500).send(error.message);
    }
}

const readOneUsuario = async (req, res) => {
    try {
        const id = req?.params?.id
        console.log('-> readOneUsuario: ' + id)

        const usuario = await UsuarioModel.findOne({ _id: id })
        if (usuario) {
            res.status(200)
            res.json({ result: 'Ok', usuario: usuario })
        } else {
            res.status(404)
            res.json({
                result: 'Not found',
                mensaje: `Usuario no encontrado: ID ${id}`
            })
        }
    } catch (error) {
        console.log('Exception en readOneUsuario: ' + error.message)
        res.status(500).send(error.message);
    }
}

const createUsuario = async (req, res) => {
    console.log('-> createUsuario')
    try {
        const usuarioModel = new UsuarioModel({
            ...req.body
        })

        const usuario = await usuarioModel.save()
        res.status(201)
        res.json({ result: 'Ok', usuario: usuario })
    } catch (error) {
        console.log('Exception en createUsuario: ' + error.message)
        res.status(500)
        res.json({ result: 'Error', mensaje: error.message });
    }
}

const updateUsuario = async (req, res) => {
    try {
        const _id = req?.params?.id
        console.log('-> updateUsuario: ' + _id)
        const usuario = await UsuarioModel.findOne({ _id: _id })
        if (usuario) {
            const cambiosdelDocumento = {
                ...req.body
            }
            const usuarioUpdated = await UsuarioModel.findByIdAndUpdate(
                _id,
                cambiosdelDocumento,
                { new: true }
            )
            res.status(201)
            res.json({ result: 'Ok', usuario: usuarioUpdated })
        } else {
            res.status(404)
            res.json({
                result: 'Not found',
                mensaje: `Usuario no encontrado: ID ${id}`
            })
        }
    } catch (error) {
        console.log('Exception en updateUsuario: ' + error.message)
        res.status(500)
        res.json({ result: 'Error', mensaje: error.message });
    }
}



module.exports = {
    readAllUsuarios,
    readOneUsuario,
    createUsuario,
    updateUsuario
}