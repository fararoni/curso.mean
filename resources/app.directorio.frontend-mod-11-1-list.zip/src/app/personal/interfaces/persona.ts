export interface Persona {
    area?: string;
    titulo?: string;
    nombrecompleto?: string;

    cargo?: string;
    correo?: string;
    extension?: string;

    edificio?: string;
    piso?: string;
    fotografia?: string;
    _id?: string;
}
