import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, tap } from 'rxjs';
import { environment } from '../../../environments/environment';

import { Persona } from '../interfaces/persona';
import { apiPersona } from '../interfaces/apiPersona';


@Injectable({
  providedIn: 'root'
})
export class PersonaService {
  private url = environment.apiUrl;
  private personas$: Subject<Persona[]> = new Subject();

  constructor(private httpClient: HttpClient) { }

  private refreshPersonas() {
    this.httpClient.get<apiPersona>(`${this.url}/directorio`)
    .subscribe( data => {
      this.personas$.next( data?.directorio);
      console.log('Respuesta de la API:', data);

    }, (error) => {
      console.error('Error al obtener datos:', error);
    });
   }
  
   getPersonas(): Subject<Persona[]> {
    console.log('----------------> Logging');
    this.refreshPersonas();
    console.log(this.personas$);
    return this.personas$;
  }
 
}
