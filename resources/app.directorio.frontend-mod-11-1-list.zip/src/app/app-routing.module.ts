import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonalListComponent } from './personal/components/personal-list/personal-list.component';

const routes: Routes = [
  { path: '', redirectTo: 'personas', pathMatch: 'full' },
  { path: 'personas', component: PersonalListComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
